
export interface UserProfile {
  name: string;
  planType: string;
  avatar: string;
}

export interface StudyTask {
  id: string;
  title: string;
  description: string;
  durationMinutes: number;
  priority: 'low' | 'medium' | 'high';
  completed: boolean;
  startTime?: string; // e.g., "09:00"
}

export interface DayPlan {
  day: number;
  focus: string;
  tasks: StudyTask[];
}

export interface StudyPlanVariant {
  title: string;
  objective: string;
  totalDurationDays: number;
  difficulty: string;
  schedule: DayPlan[];
}

export interface StudyPlan {
  isActivated?: boolean;
  startDate?: string;
  endDate?: string;
  hoursPerWeek?: number;
  selectedIntensity: 'gentle' | 'standard' | 'hardcore';
  variants: {
    gentle: StudyPlanVariant;
    standard: StudyPlanVariant;
    hardcore: StudyPlanVariant;
  };
}

export interface RoutineDetails {
  commitments: string;
  currentBlocks: string;
  energyLevels: string;
  goals: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export type ViewState = 'dashboard' | 'planner' | 'calendar' | 'assistant';
