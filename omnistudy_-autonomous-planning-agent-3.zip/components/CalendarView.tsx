
import React, { useState } from 'react';
import { StudyPlan } from '../types';

interface CalendarViewProps {
  plan: StudyPlan | null;
}

const CalendarView: React.FC<CalendarViewProps> = ({ plan }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const daysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

  const renderDays = () => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const totalDays = daysInMonth(year, month);
    const startDay = firstDayOfMonth(year, month);
    
    const dayCells = [];
    for (let i = 0; i < startDay; i++) {
      dayCells.push(<div key={`empty-${i}`} className="h-32 border border-slate-800 bg-[#0d1117]"></div>);
    }

    const activeVariant = plan ? plan.variants[plan.selectedIntensity] : null;

    for (let d = 1; d <= totalDays; d++) {
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      
      let dayTasks: any[] = [];
      let focus = '';
      if (plan && plan.isActivated && plan.startDate && activeVariant) {
        const start = new Date(plan.startDate);
        const current = new Date(dateStr);
        const diffTime = current.getTime() - start.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
        
        const matchingDay = activeVariant.schedule.find(s => s.day === diffDays);
        if (matchingDay) {
          dayTasks = matchingDay.tasks;
          focus = matchingDay.focus;
        }
      }

      dayCells.push(
        <div key={d} className="h-36 border border-slate-800 bg-[#161b22] p-3 overflow-y-auto transition-colors hover:bg-slate-800/40">
          <div className="flex justify-between items-start mb-1">
             <span className="text-xs font-black text-slate-600">{d}</span>
          </div>
          {focus && (
            <div className="mb-1.5 text-[9px] bg-indigo-900/30 text-indigo-300 px-1.5 py-0.5 rounded font-black uppercase tracking-tighter truncate border border-indigo-500/10">
              {focus}
            </div>
          )}
          <div className="space-y-1">
            {dayTasks.map(task => (
              <div key={task.id} className={`text-[8px] px-1.5 py-1 rounded-md font-bold truncate border ${
                task.priority === 'high' ? 'bg-rose-900/20 text-rose-400 border-rose-500/10' :
                task.priority === 'medium' ? 'bg-amber-900/20 text-amber-400 border-amber-500/10' : 'bg-emerald-900/20 text-emerald-400 border-emerald-500/10'
              }`}>
                {task.startTime} {task.title}
              </div>
            ))}
          </div>
        </div>
      );
    }
    return dayCells;
  };

  const nextMonth = () => setCurrentMonth(new Date(currentMonth.setMonth(currentMonth.getMonth() + 1)));
  const prevMonth = () => setCurrentMonth(new Date(currentMonth.setMonth(currentMonth.getMonth() - 1)));

  return (
    <div className="animate-in fade-in duration-500 space-y-8 pb-20">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-4xl font-black text-white uppercase tracking-tighter">
            {currentMonth.toLocaleString('default', { month: 'long', year: 'numeric' })}
          </h2>
          <p className="text-slate-500 font-medium text-sm mt-1">Holistic view of your academic synchronization.</p>
        </div>
        <div className="flex gap-4">
          <button onClick={prevMonth} className="w-12 h-12 flex items-center justify-center bg-[#161b22] border border-slate-800 hover:bg-slate-800 text-white rounded-2xl transition-all shadow-xl">
            <i className="fas fa-chevron-left"></i>
          </button>
          <button onClick={nextMonth} className="w-12 h-12 flex items-center justify-center bg-[#161b22] border border-slate-800 hover:bg-slate-800 text-white rounded-2xl transition-all shadow-xl">
            <i className="fas fa-chevron-right"></i>
          </button>
        </div>
      </header>

      <div className="bg-[#161b22] border border-slate-800 rounded-[32px] overflow-hidden shadow-2xl">
        <div className="grid grid-cols-7 border-b border-slate-800 bg-[#0d1117]">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} className="py-4 text-center text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">{day}</div>
          ))}
        </div>
        <div className="grid grid-cols-7">
          {renderDays()}
        </div>
      </div>

      {!plan?.isActivated && (
        <div className="p-12 bg-indigo-900/5 border border-indigo-500/10 rounded-[40px] text-center">
          <div className="w-16 h-16 bg-[#0d1117] rounded-3xl flex items-center justify-center text-slate-700 mx-auto mb-6">
             <i className="fas fa-radar text-2xl"></i>
          </div>
          <p className="text-slate-400 font-black uppercase tracking-widest text-sm">Synchronicity Offline</p>
          <p className="text-slate-600 text-xs mt-3 max-w-sm mx-auto">Activate your tri-phase roadmap in the AI Planner to populate this neural network visualization.</p>
        </div>
      )}
    </div>
  );
};

export default CalendarView;
