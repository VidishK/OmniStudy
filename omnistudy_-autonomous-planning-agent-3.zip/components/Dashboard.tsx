
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { StudyPlan, UserProfile } from '../types';

interface DashboardProps {
  plan: StudyPlan | null;
  user: UserProfile;
  onToggleTask: (dayNum: number, taskId: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ plan, user, onToggleTask }) => {
  const hasActivePlan = plan && plan.isActivated;
  const activeVariant = plan ? plan.variants[plan.selectedIntensity] : null;
  
  const completedTasks = activeVariant?.schedule.flatMap(d => d.tasks).filter(t => t.completed).length || 0;
  const totalTasks = activeVariant?.schedule.flatMap(d => d.tasks).length || 0;
  const progressPercent = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  // Find the tasks for the current "Study Day" (simulated based on start date)
  let todayTasks: any[] = [];
  let currentStudyDay = 1;
  if (hasActivePlan && plan.startDate && activeVariant) {
    const start = new Date(plan.startDate);
    const today = new Date();
    const diffTime = today.getTime() - start.getTime();
    currentStudyDay = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
    const matchingDay = activeVariant.schedule.find(s => s.day === currentStudyDay);
    if (matchingDay) todayTasks = matchingDay.tasks;
  }

  const chartData = hasActivePlan ? [
    { name: 'Mon', hours: 4, color: '#818cf8' },
    { name: 'Tue', hours: 3, color: '#818cf8' },
    { name: 'Wed', hours: 5, color: '#818cf8' },
    { name: 'Thu', hours: 2, color: '#818cf8' },
    { name: 'Fri', hours: 6, color: '#818cf8' },
    { name: 'Sat', hours: 0, color: '#6366f1' },
    { name: 'Sun', hours: 0, color: '#6366f1' },
  ] : [
    { name: 'Mon', hours: 0, color: '#1e293b' },
    { name: 'Tue', hours: 0, color: '#1e293b' },
    { name: 'Wed', hours: 0, color: '#1e293b' },
    { name: 'Thu', hours: 0, color: '#1e293b' },
    { name: 'Fri', hours: 0, color: '#1e293b' },
    { name: 'Sat', hours: 0, color: '#1e293b' },
    { name: 'Sun', hours: 0, color: '#1e293b' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500 text-slate-100">
      <header>
        <h1 className="text-3xl font-black text-white uppercase tracking-tight">System Status: {user.name}</h1>
        <p className="text-slate-500 font-medium">
          {hasActivePlan 
            ? `Active ${plan.selectedIntensity.toUpperCase()} Mission in progress.` 
            : "Standby mode. Architect a plan to begin."}
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-[#161b22] p-8 rounded-[32px] border border-slate-800 flex items-center gap-6 shadow-xl shadow-black/20">
          <div className="w-16 h-16 bg-emerald-900/10 rounded-2xl flex items-center justify-center text-emerald-500 border border-emerald-900/20">
            <i className="fas fa-clock text-2xl"></i>
          </div>
          <div>
            <p className="text-xs text-slate-500 font-black uppercase tracking-widest">Est. Workload</p>
            <h3 className="text-3xl font-black text-white">{hasActivePlan ? `${plan.hoursPerWeek}h/wk` : '0h'}</h3>
          </div>
        </div>
        <div className="bg-[#161b22] p-8 rounded-[32px] border border-slate-800 flex items-center gap-6 shadow-xl shadow-black/20">
          <div className="w-16 h-16 bg-indigo-900/10 rounded-2xl flex items-center justify-center text-indigo-400 border border-indigo-900/20">
            <i className="fas fa-check-double text-2xl"></i>
          </div>
          <div>
            <p className="text-xs text-slate-500 font-black uppercase tracking-widest">Quota Clear</p>
            <h3 className="text-3xl font-black text-white">{completedTasks}/{totalTasks}</h3>
          </div>
        </div>
        <div className="bg-[#161b22] p-8 rounded-[32px] border border-slate-800 flex items-center gap-6 shadow-xl shadow-black/20">
          <div className="w-16 h-16 bg-amber-900/10 rounded-2xl flex items-center justify-center text-amber-500 border border-amber-900/20">
            <i className="fas fa-fire text-2xl"></i>
          </div>
          <div>
            <p className="text-xs text-slate-500 font-black uppercase tracking-widest">Global Progress</p>
            <h3 className="text-3xl font-black text-white">{progressPercent}%</h3>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <div className="space-y-10">
          <div className="bg-[#161b22] p-8 rounded-[32px] border border-slate-800 shadow-2xl">
            <h3 className="text-sm font-black text-slate-100 mb-8 uppercase tracking-widest">Daily Briefing (Day {currentStudyDay})</h3>
            {hasActivePlan ? (
              <div className="space-y-4">
                {todayTasks.length > 0 ? todayTasks.map(task => (
                  <div key={task.id} className="flex items-center gap-4 p-4 bg-[#0d1117] rounded-2xl border border-slate-800 group transition-all hover:border-indigo-500/50">
                    <button 
                      onClick={() => onToggleTask(currentStudyDay, task.id)}
                      className={`w-6 h-6 rounded border-2 flex items-center justify-center transition-all ${
                        task.completed ? 'bg-indigo-600 border-indigo-600' : 'border-slate-700'
                      }`}
                    >
                      {task.completed && <i className="fas fa-check text-[10px] text-white"></i>}
                    </button>
                    <div className="flex-1">
                      <p className={`text-sm font-bold ${task.completed ? 'text-slate-500 line-through' : 'text-slate-200'}`}>
                        {task.title}
                      </p>
                      <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">{task.startTime} • {task.durationMinutes}m</p>
                    </div>
                  </div>
                )) : (
                  <p className="text-slate-500 text-center py-4 italic">No tasks scheduled for today. Rest and recover.</p>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-slate-700 space-y-4 py-8">
                <i className="fas fa-clipboard-list text-5xl opacity-10"></i>
                <p className="text-xs font-bold uppercase tracking-widest">No active mission</p>
              </div>
            )}
          </div>

          <div className="bg-[#161b22] p-8 rounded-[32px] border border-slate-800 shadow-2xl">
            <h3 className="text-sm font-black text-slate-100 mb-8 uppercase tracking-widest">Cognitive Load Distribution</h3>
            <div className="h-[220px]">
              {hasActivePlan ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#475569', fontSize: 10, fontWeight: 'bold'}} dy={10} />
                    <YAxis axisLine={false} tickLine={false} tick={{fill: '#475569', fontSize: 10, fontWeight: 'bold'}} />
                    <Tooltip 
                      cursor={{fill: '#0f172a'}}
                      contentStyle={{ backgroundColor: '#161b22', borderRadius: '16px', border: '1px solid #1e293b', padding: '12px' }}
                      itemStyle={{ color: '#fff', fontSize: '12px', fontWeight: 'bold' }}
                    />
                    <Bar dataKey="hours" radius={[8, 8, 0, 0]}>
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-slate-700 space-y-4">
                  <i className="fas fa-chart-bar text-5xl opacity-10"></i>
                  <p className="text-xs font-bold uppercase tracking-widest">Telemetry standby</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="bg-[#161b22] p-8 rounded-[32px] border border-slate-800 shadow-2xl h-fit">
          <h3 className="text-sm font-black text-slate-100 mb-8 uppercase tracking-widest">Operational Core</h3>
          {hasActivePlan ? (
            <div className="space-y-6">
              <div className="p-6 bg-indigo-900/10 rounded-[24px] border border-indigo-500/20">
                <div className="flex justify-between items-start mb-2">
                   <h4 className="font-black text-indigo-100 text-lg uppercase leading-tight">{activeVariant?.title}</h4>
                   <span className="bg-indigo-600 text-[9px] font-black px-2 py-0.5 rounded text-white tracking-widest uppercase">{plan.selectedIntensity}</span>
                </div>
                <p className="text-sm text-indigo-300 font-medium">{activeVariant?.objective}</p>
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border border-slate-800 rounded-2xl bg-[#0d1117]">
                  <span className="text-slate-200 text-sm font-bold truncate pr-4">{activeVariant?.schedule.find(s => s.day === currentStudyDay)?.focus || 'Syncing...'}</span>
                  <span className="text-[10px] bg-slate-800 text-slate-500 px-3 py-1 rounded-lg font-black tracking-widest shrink-0">DAY {currentStudyDay.toString().padStart(2, '0')}</span>
                </div>
                <div className="space-y-2">
                   <div className="flex justify-between text-[10px] font-black text-slate-500 uppercase tracking-widest">
                     <span>Mission Completion</span>
                     <span>{progressPercent}%</span>
                   </div>
                   <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
                     <div className="bg-indigo-500 h-full transition-all duration-1000 shadow-[0_0_15px_rgba(99,102,241,0.4)]" style={{ width: `${progressPercent}%` }}></div>
                   </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center py-12">
              <div className="w-20 h-20 bg-[#0d1117] rounded-3xl flex items-center justify-center text-slate-800 mb-6 border border-slate-800">
                <i className="fas fa-rocket text-3xl"></i>
              </div>
              <p className="text-slate-400 mb-4 font-black uppercase tracking-tighter">Ready for deployment?</p>
              <p className="text-slate-600 text-xs font-medium mb-8 max-w-[240px] leading-relaxed">Your neural networks are on standby. Architect an autonomous plan to synchronize.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
