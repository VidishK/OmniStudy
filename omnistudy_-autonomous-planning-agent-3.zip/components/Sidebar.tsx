
import React, { useState } from 'react';
import { ViewState, UserProfile } from '../types';

interface SidebarProps {
  currentView: ViewState;
  onViewChange: (view: ViewState) => void;
  user: UserProfile;
  onUpdateName: (name: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onViewChange, user, onUpdateName }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [tempName, setTempName] = useState(user.name);

  const menuItems: { id: ViewState; icon: string; label: string }[] = [
    { id: 'dashboard', icon: 'fa-chart-line', label: 'Dashboard' },
    { id: 'planner', icon: 'fa-calendar-plus', label: 'AI Planner' },
    { id: 'calendar', icon: 'fa-calendar-alt', label: 'Calendar' },
    { id: 'assistant', icon: 'fa-robot', label: 'AI Assistant' },
  ];

  const handleSaveName = () => {
    onUpdateName(tempName);
    setIsEditing(false);
  };

  return (
    <div className="w-20 md:w-64 bg-[#0d1117] border-r border-slate-800 h-screen flex flex-col sticky top-0 transition-all duration-300">
      <div className="p-6 flex items-center gap-3">
        <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shrink-0">
          <i className="fas fa-brain text-xl"></i>
        </div>
        <span className="hidden md:block font-bold text-slate-100 text-xl tracking-tight">OmniStudy</span>
      </div>

      <nav className="flex-1 px-4 py-6 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onViewChange(item.id)}
            className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all ${
              currentView === item.id
                ? 'bg-indigo-900/40 text-indigo-400 shadow-sm'
                : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            <i className={`fas ${item.icon} text-lg w-6`}></i>
            <span className="hidden md:block font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-6 border-t border-slate-800">
        <div className="hidden md:flex flex-col gap-2 p-3 bg-slate-800/50 rounded-xl">
          <div className="flex items-center gap-3">
            <img src={user.avatar} className="w-10 h-10 rounded-full border border-slate-700 shadow-sm" alt="User" />
            <div className="overflow-hidden flex-1">
              {isEditing ? (
                <input 
                  autoFocus
                  className="text-sm font-semibold text-slate-100 w-full bg-slate-900 border border-slate-700 rounded px-1 outline-none"
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                  onBlur={handleSaveName}
                  onKeyDown={(e) => e.key === 'Enter' && handleSaveName()}
                />
              ) : (
                <p 
                  className="text-sm font-semibold text-slate-100 truncate cursor-pointer hover:text-indigo-400"
                  onClick={() => setIsEditing(true)}
                >
                  {user.name}
                </p>
              )}
              <p className="text-xs text-slate-500 truncate">{user.planType}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
