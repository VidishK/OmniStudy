
import React, { useState } from 'react';
import { generateStudyPlan, optimizeRoutine } from '../services/geminiService';
import { StudyPlan, RoutineDetails, StudyPlanVariant, StudyTask } from '../types';

interface PlannerProps {
  onPlanGenerated: (plan: StudyPlan) => void;
  activePlan: StudyPlan | null;
  onToggleTask: (dayNum: number, taskId: string) => void;
}

const Planner: React.FC<PlannerProps> = ({ onPlanGenerated, activePlan, onToggleTask }) => {
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<'generate' | 'optimize'>('generate');
  const [showOptions, setShowOptions] = useState(false);
  
  // Selection State
  const [selectedIntensity, setSelectedIntensity] = useState<'gentle' | 'standard' | 'hardcore'>('standard');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().split('T')[0];
  });
  const [hoursPerWeek, setHoursPerWeek] = useState(20);
  const [goal, setGoal] = useState('');
  const [level, setLevel] = useState('Intermediate');

  const [routine, setRoutine] = useState<RoutineDetails>({
    commitments: '',
    currentBlocks: '',
    energyLevels: 'Morning',
    goals: ''
  });

  const handleProcess = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const variants = mode === 'generate' 
        ? await generateStudyPlan(goal, startDate, endDate, level, hoursPerWeek)
        : await optimizeRoutine(routine);
      
      onPlanGenerated({ 
        isActivated: false, 
        startDate, 
        endDate, 
        hoursPerWeek, 
        selectedIntensity: 'standard', 
        variants 
      }); 
      setShowOptions(true);
    } catch (err) {
      console.error(err);
      alert('Architecting failed. Please check your inputs and API key.');
    } finally {
      setLoading(false);
    }
  };

  const handleActivate = () => {
    if (!activePlan) return;
    onPlanGenerated({ 
      ...activePlan, 
      isActivated: true,
      selectedIntensity
    });
    setShowOptions(false);
  };

  const activeVariant: StudyPlanVariant | undefined = activePlan?.variants[activePlan.isActivated ? activePlan.selectedIntensity : selectedIntensity];

  const addToGoogleCalendar = (task: StudyTask, dayNum: number) => {
    const startBase = new Date(activePlan?.startDate || startDate);
    const taskDate = new Date(startBase);
    taskDate.setDate(startBase.getDate() + (dayNum - 1));
    const [hours, minutes] = (task.startTime || '09:00').split(':');
    const start = new Date(taskDate);
    start.setHours(parseInt(hours), parseInt(minutes), 0);
    const end = new Date(start.getTime() + task.durationMinutes * 60000);
    const formatTime = (date: Date) => date.toISOString().replace(/-|:|\.\d\d\d/g, "");
    const url = `https://www.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(task.title)}&dates=${formatTime(start)}/${formatTime(end)}&details=${encodeURIComponent(task.description)}&sf=true&output=xml`;
    window.open(url, '_blank');
  };

  const downloadIcsFile = () => {
    if (!activeVariant || !activePlan?.startDate) return;
    
    let icsContent = "BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//OmniStudy//Academic Planner//EN\n";
    const startBase = new Date(activePlan.startDate);

    activeVariant.schedule.forEach((day) => {
      day.tasks.forEach((task) => {
        const taskDate = new Date(startBase);
        taskDate.setDate(startBase.getDate() + (day.day - 1));
        const [hours, minutes] = (task.startTime || '09:00').split(':');
        
        const start = new Date(taskDate);
        start.setHours(parseInt(hours), parseInt(minutes), 0);
        const end = new Date(start.getTime() + task.durationMinutes * 60000);

        const formatICSDate = (date: Date) => date.toISOString().replace(/-|:|\.\d\d\d/g, "");

        icsContent += "BEGIN:VEVENT\n";
        icsContent += `SUMMARY:${task.title}\n`;
        icsContent += `DTSTART:${formatICSDate(start)}\n`;
        icsContent += `DTEND:${formatICSDate(end)}\n`;
        icsContent += `DESCRIPTION:${task.description.replace(/\n/g, "\\n")}\n`;
        icsContent += "END:VEVENT\n";
      });
    });

    icsContent += "END:VCALENDAR";

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', `${activeVariant.title.replace(/\s+/g, '_')}_Schedule.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-500 pb-24 text-slate-100">
      <header className="text-center">
        <h1 className="text-4xl font-black text-white mb-2 tracking-tight uppercase">Plan Architecture</h1>
        <p className="text-slate-500 font-medium">
          {!activePlan ? "Define your mission parameters." : "Compare intensity models before deployment."}
        </p>
      </header>

      {(!activePlan || !activePlan.isActivated) && !loading ? (
        <div className="bg-[#161b22] rounded-[32px] shadow-2xl border border-slate-800 overflow-hidden">
          {!showOptions ? (
            <>
              <div className="flex bg-[#0d1117] p-2 m-4 rounded-2xl border border-slate-800">
                <button 
                  onClick={() => setMode('generate')}
                  className={`flex-1 py-3 rounded-xl font-bold text-xs uppercase tracking-widest transition-all ${mode === 'generate' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'}`}
                >
                  New Plan
                </button>
                <button 
                  onClick={() => setMode('optimize')}
                  className={`flex-1 py-3 rounded-xl font-bold text-xs uppercase tracking-widest transition-all ${mode === 'optimize' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'}`}
                >
                  Optimize
                </button>
              </div>

              <div className="p-10">
                <form onSubmit={handleProcess} className="space-y-8">
                  {mode === 'generate' ? (
                    <>
                      <div className="space-y-1">
                        <label className="text-xs font-black text-slate-500 uppercase tracking-widest ml-1">Learning Objective</label>
                        <textarea
                          value={goal}
                          onChange={(e) => setGoal(e.target.value)}
                          placeholder="e.g., Quantum Mechanics or React Framework..."
                          className="w-full px-6 py-5 bg-[#0d1117] border border-slate-700 rounded-3xl text-lg text-white focus:ring-4 focus:ring-indigo-900/10 focus:border-indigo-500 transition-all outline-none min-h-[140px] resize-none"
                          required
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-1">
                          <label className="text-xs font-black text-slate-500 uppercase tracking-widest ml-1">Start</label>
                          <input type="date" className="w-full px-5 py-4 bg-[#0d1117] border border-slate-700 rounded-2xl text-white outline-none focus:border-indigo-500" value={startDate} onChange={e => setStartDate(e.target.value)} />
                        </div>
                        <div className="space-y-1">
                          <label className="text-xs font-black text-slate-500 uppercase tracking-widest ml-1">End</label>
                          <input type="date" className="w-full px-5 py-4 bg-[#0d1117] border border-slate-700 rounded-2xl text-white outline-none focus:border-indigo-500" value={endDate} onChange={e => setEndDate(e.target.value)} />
                        </div>
                        <div className="space-y-1">
                          <label className="text-xs font-black text-slate-500 uppercase tracking-widest ml-1">Hrs/Week</label>
                          <input type="number" className="w-full px-5 py-4 bg-[#0d1117] border border-slate-700 rounded-2xl text-white outline-none focus:border-indigo-500" value={hoursPerWeek} onChange={e => setHoursPerWeek(Number(e.target.value))} min="1" max="168" />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-black text-slate-500 uppercase tracking-widest ml-1">Proficiency</label>
                        <select value={level} onChange={(e) => setLevel(e.target.value)} className="w-full px-5 py-4 bg-[#0d1117] border border-slate-700 rounded-2xl text-white outline-none focus:border-indigo-500">
                          <option>Absolute Beginner</option><option>Intermediate</option><option>Advanced</option>
                        </select>
                      </div>
                    </>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-1">
                        <label className="text-xs font-black text-slate-500 uppercase tracking-widest ml-1">Fixed Commitments</label>
                        <input className="w-full px-5 py-4 bg-[#0d1117] border border-slate-700 rounded-2xl text-white outline-none" placeholder="Work, gym..." value={routine.commitments} onChange={e => setRoutine({...routine, commitments: e.target.value})} />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-black text-slate-500 uppercase tracking-widest ml-1">Energy Peak</label>
                        <select className="w-full px-5 py-4 bg-[#0d1117] border border-slate-700 rounded-2xl text-white outline-none" value={routine.energyLevels} onChange={e => setRoutine({...routine, energyLevels: e.target.value})}>
                          <option>Morning</option><option>Afternoon</option><option>Evening</option>
                        </select>
                      </div>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full py-5 bg-indigo-600 text-white rounded-3xl font-black text-xl hover:bg-indigo-700 shadow-xl shadow-indigo-900/20 flex items-center justify-center gap-3 transition-all active:scale-[0.98]"
                  >
                    <i className="fas fa-magic"></i>
                    Initiate Architect
                  </button>
                </form>
              </div>
            </>
          ) : (
            <div className="p-0 animate-in fade-in zoom-in-95">
              <div className="bg-[#0d1117] p-8 border-b border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
                <div>
                  <h3 className="text-2xl font-black text-white uppercase">Variant Review</h3>
                  <p className="text-slate-500 text-sm">Compare schedules before finalizing your mission.</p>
                </div>
                <div className="flex bg-[#161b22] p-1.5 rounded-2xl border border-slate-800">
                  {(['gentle', 'standard', 'hardcore'] as const).map(opt => (
                    <button
                      key={opt}
                      onClick={() => setSelectedIntensity(opt)}
                      className={`px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${selectedIntensity === opt ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/40' : 'text-slate-500 hover:text-slate-300'}`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-8 space-y-8 max-h-[600px] overflow-y-auto custom-scrollbar bg-[#0d1117]/50">
                <div className="bg-indigo-900/10 border border-indigo-500/20 p-6 rounded-3xl">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
                    <div>
                      <h4 className="text-indigo-400 text-xs font-black uppercase tracking-tighter">Selected Strategy: {selectedIntensity}</h4>
                      <p className="text-white text-lg font-bold mt-1">{activePlan?.variants[selectedIntensity]?.title}</p>
                    </div>
                    <div className="text-left md:text-right">
                      <p className="text-slate-500 text-xs uppercase font-bold tracking-widest">Total Volume</p>
                      <p className="text-indigo-300 font-black text-xl">{activePlan?.hoursPerWeek}h/Week • {activePlan?.variants[selectedIntensity]?.totalDurationDays} Days</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  {activePlan?.variants[selectedIntensity]?.schedule.map(day => (
                    <div key={day.day} className="bg-[#161b22] rounded-3xl border border-slate-800 p-6">
                      <div className="flex justify-between items-center mb-4 pb-4 border-b border-slate-800">
                        <p className="font-black text-white uppercase text-xs tracking-widest">Day {day.day}: {day.focus}</p>
                      </div>
                      <div className="space-y-4">
                        {day.tasks.map(t => (
                          <div key={t.id} className="flex gap-4 items-center">
                             <div className="w-16 text-xs font-mono text-indigo-400 shrink-0">{t.startTime}</div>
                             <div className="flex-1">
                               <p className="text-slate-200 font-bold text-sm">{t.title}</p>
                               <p className="text-slate-500 text-xs mt-0.5">{t.durationMinutes} minutes</p>
                             </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-8 bg-[#0d1117] border-t border-slate-800 flex flex-col md:flex-row gap-6">
                <button 
                  onClick={() => { setShowOptions(false); onPlanGenerated(null as any); }}
                  className="flex-1 py-5 text-slate-400 font-black uppercase text-xs tracking-widest border border-slate-800 rounded-3xl hover:bg-slate-800 transition-all"
                >
                  Discard
                </button>
                <button 
                  onClick={handleActivate}
                  className="flex-[2] py-5 bg-indigo-600 text-white font-black uppercase text-xs tracking-widest rounded-3xl hover:bg-indigo-700 shadow-2xl shadow-indigo-900/40 flex items-center justify-center gap-3 transition-all active:scale-[0.98]"
                >
                  <i className="fas fa-rocket"></i>
                  Deploy {selectedIntensity} Mission
                </button>
              </div>
            </div>
          )}
        </div>
      ) : loading ? (
        <div className="bg-[#161b22] p-24 rounded-[32px] shadow-2xl border border-slate-800 flex flex-col items-center justify-center space-y-8 text-center">
          <div className="relative">
             <div className="w-20 h-20 border-4 border-slate-800 border-t-indigo-500 rounded-full animate-spin"></div>
             <i className="fas fa-atom absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-indigo-500 text-2xl"></i>
          </div>
          <div>
            <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Architecting Tri-Phase Roadmap</h3>
            <p className="text-slate-500 max-w-sm mt-3 leading-relaxed">Gemini is synthesizing Gentle, Standard, and Hardcore variants based on your workload constraints across the full date range.</p>
          </div>
        </div>
      ) : (
        <div className="space-y-8 animate-in fade-in duration-700">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center bg-[#161b22] p-8 rounded-3xl border border-slate-800 shadow-xl gap-6">
            <div>
              <h2 className="text-2xl font-black text-white uppercase tracking-tight">{activeVariant?.title}</h2>
              <div className="flex flex-wrap items-center gap-4 mt-2">
                <span className={`text-[10px] font-black uppercase px-3 py-1 rounded-full ${
                  activePlan?.selectedIntensity === 'hardcore' ? 'bg-rose-900/30 text-rose-400' :
                  activePlan?.selectedIntensity === 'gentle' ? 'bg-emerald-900/30 text-emerald-400' : 'bg-indigo-900/30 text-indigo-400'
                }`}>
                  {activePlan?.selectedIntensity} MODE
                </span>
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Range: {activePlan?.startDate} — {activePlan?.endDate}</span>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
              <button 
                onClick={downloadIcsFile}
                className="text-xs font-black uppercase tracking-widest bg-emerald-600 text-white px-6 py-3 rounded-2xl border border-emerald-500 shadow-lg shadow-emerald-500/20 hover:bg-emerald-700 transition-all flex items-center justify-center gap-2"
              >
                <i className="fas fa-file-export"></i>
                Bulk Sync (ICS)
              </button>
              <button onClick={() => { setShowOptions(false); onPlanGenerated(null as any); }} className="text-rose-500 text-xs font-black uppercase tracking-widest hover:bg-rose-900/20 px-6 py-3 rounded-2xl border border-rose-900/30 transition-all flex items-center justify-center">
                Terminate Plan
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-8">
            {activeVariant?.schedule.map((day) => (
              <div key={day.day} className="bg-[#161b22] rounded-[32px] border border-slate-800 shadow-md overflow-hidden transition-all hover:border-slate-700">
                <div className="bg-[#0d1117] px-8 py-5 border-b border-slate-800 flex justify-between items-center">
                  <h3 className="font-black text-slate-100 uppercase text-sm tracking-widest">Day {day.day}: {day.focus}</h3>
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] text-slate-500 font-mono tracking-tighter">{new Date(new Date(activePlan?.startDate!).getTime() + (day.day-1)*86400000).toDateString()}</span>
                  </div>
                </div>
                <div className="p-8 space-y-6">
                  {day.tasks.map((task) => (
                    <div key={task.id} className="flex flex-col sm:flex-row items-start gap-6 p-6 bg-[#0d1117]/30 border border-slate-800 rounded-3xl hover:bg-slate-800/30 transition-all group">
                      <div className="mt-1">
                        <button 
                          onClick={() => onToggleTask(day.day, task.id)}
                          className={`w-7 h-7 border-2 rounded-lg flex items-center justify-center transition-all ${
                            task.completed ? 'bg-indigo-600 border-indigo-600' : 'border-slate-700 hover:border-indigo-500'
                          }`}
                        >
                          {task.completed && <i className="fas fa-check text-xs text-white"></i>}
                        </button>
                      </div>
                      <div className="flex-1 w-full">
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-2 gap-2">
                          <h4 className={`font-black text-lg tracking-tight ${task.completed ? 'text-slate-500 line-through' : 'text-white'}`}>{task.title}</h4>
                          <div className="flex items-center gap-4">
                            <span className="text-xs font-black bg-[#0d1117] px-3 py-1 rounded-xl text-indigo-400 border border-slate-800">{task.startTime}</span>
                            <span className="text-xs text-slate-500 font-bold">{task.durationMinutes}m</span>
                          </div>
                        </div>
                        <p className={`text-sm leading-relaxed mb-4 ${task.completed ? 'text-slate-600' : 'text-slate-400'}`}>{task.description}</p>
                        <div className="flex justify-between items-center">
                          <span className={`text-[10px] uppercase font-black px-3 py-1 rounded-lg ${
                            task.priority === 'high' ? 'bg-rose-900/40 text-rose-400 border border-rose-500/20' :
                            task.priority === 'medium' ? 'bg-amber-900/40 text-amber-400 border border-amber-500/20' : 'bg-emerald-900/40 text-emerald-400 border border-emerald-500/20'
                          }`}>
                            {task.priority} Priority
                          </span>
                          <button 
                            onClick={() => addToGoogleCalendar(task, day.day)}
                            className="text-[10px] flex items-center gap-2 text-indigo-400 font-black uppercase tracking-widest bg-indigo-900/20 px-4 py-2 rounded-xl border border-indigo-500/20 hover:bg-indigo-900/40 transition-colors"
                          >
                            <i className="fab fa-google"></i>
                            Calendar
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Planner;
