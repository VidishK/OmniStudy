
import React, { useState, useRef, useEffect } from 'react';
import { getAssistantResponse } from '../services/geminiService';
import { ChatMessage } from '../types';

const Assistant: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: 'Hi! I\'m your OmniStudy assistant. Ask me anything about your current plan, or need help understanding a complex topic?', timestamp: new Date() }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage: ChatMessage = { role: 'user', text: input, timestamp: new Date() };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));
      
      const response = await getAssistantResponse(history, input);
      setMessages(prev => [...prev, { role: 'model', text: response || 'Sorry, I couldn\'t process that.', timestamp: new Date() }]);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-120px)] max-w-5xl mx-auto bg-[#161b22] rounded-3xl shadow-xl border border-slate-800 overflow-hidden animate-in zoom-in-95 duration-500">
      <header className="px-8 py-6 border-b border-slate-800 bg-[#0d1117] flex items-center gap-4">
        <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center text-white">
          <i className="fas fa-robot"></i>
        </div>
        <div>
          <h2 className="font-bold text-white">OmniStudy Intelligence</h2>
          <p className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
            Agent Synced
          </p>
        </div>
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-6">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] rounded-2xl px-6 py-4 shadow-sm ${
              msg.role === 'user' 
                ? 'bg-indigo-600 text-white rounded-tr-none' 
                : 'bg-slate-900 text-slate-200 rounded-tl-none border border-slate-800'
            }`}>
              <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
              <p className={`text-[10px] mt-2 opacity-60 ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-slate-900 rounded-2xl rounded-tl-none px-6 py-4 border border-slate-800">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-slate-600 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-slate-600 rounded-full animate-bounce [animation-delay:-.3s]"></div>
                <div className="w-2 h-2 bg-slate-600 rounded-full animate-bounce [animation-delay:-.5s]"></div>
              </div>
            </div>
          </div>
        )}
      </div>

      <footer className="p-6 border-t border-slate-800 bg-[#0d1117]">
        <form onSubmit={handleSend} className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask anything..."
            className="w-full pl-6 pr-16 py-4 bg-[#161b22] border border-slate-700 rounded-2xl text-white focus:ring-4 focus:ring-indigo-900/20 focus:border-indigo-500 transition-all outline-none"
          />
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:opacity-50 transition-colors"
          >
            <i className="fas fa-paper-plane"></i>
          </button>
        </form>
      </footer>
    </div>
  );
};

export default Assistant;
