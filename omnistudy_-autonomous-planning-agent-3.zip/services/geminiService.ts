
import { GoogleGenAI, Type } from "@google/genai";
// Import RoutineDetails from types to fix compilation error on line 79
import { StudyPlan, RoutineDetails } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const scheduleSchema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING },
    objective: { type: Type.STRING },
    totalDurationDays: { type: Type.NUMBER },
    difficulty: { type: Type.STRING },
    schedule: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          day: { type: Type.NUMBER },
          focus: { type: Type.STRING },
          tasks: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                durationMinutes: { type: Type.NUMBER },
                priority: { type: Type.STRING },
                completed: { type: Type.BOOLEAN },
                startTime: { type: Type.STRING }
              },
              required: ["id", "title", "description", "durationMinutes", "priority", "completed", "startTime"]
            }
          }
        },
        required: ["day", "focus", "tasks"]
      }
    }
  },
  required: ["title", "objective", "totalDurationDays", "difficulty", "schedule"]
};

export const generateStudyPlan = async (goal: string, startDate: string, endDate: string, level: string, hoursPerWeek: number): Promise<any> => {
  const prompt = `Create a highly structured study architecture for: "${goal}".
  Date Range: ${startDate} to ${endDate}.
  Current Level: ${level}.
  Target Workload: ${hoursPerWeek} hours per week.

  I need THREE variants of this schedule:
  1. GENTLE: Focuses on sustainability, lower cognitive load per day, more breaks.
  2. STANDARD: Balanced approach for effective retention.
  3. HARDCORE: High-intensity, immersion-based, for rapid mastery.

  Each variant must strictly respect the ${hoursPerWeek} hours/week limit.
  Return JSON containing "gentle", "standard", and "hardcore" objects each following the StudyPlanVariant schema.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          gentle: scheduleSchema,
          standard: scheduleSchema,
          hardcore: scheduleSchema
        },
        required: ["gentle", "standard", "hardcore"]
      }
    }
  });

  return JSON.parse(response.text || '{}');
};

// Fix: Import RoutineDetails from ../types to resolve "Cannot find name 'RoutineDetails'"
export const optimizeRoutine = async (details: RoutineDetails): Promise<any> => {
  // Optimization also returns 3 variants now for consistency
  const prompt = `Optimize this routine: ${JSON.stringify(details)}. 
  Provide 3 intensity variants (gentle, standard, hardcore).`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          gentle: scheduleSchema,
          standard: scheduleSchema,
          hardcore: scheduleSchema
        },
        required: ["gentle", "standard", "hardcore"]
      }
    }
  });

  return JSON.parse(response.text || '{}');
};

export const getAssistantResponse = async (history: {role: string, parts: {text: string}[]}[], message: string) => {
  // Fix: Incorporate session history into the chat creation to maintain conversation state
  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    history: history as any,
    config: {
      systemInstruction: "You are OmniStudy, an autonomous academic planning agent. You help students understand complex concepts and refine schedules."
    }
  });

  const response = await chat.sendMessage({ message });
  return response.text;
};
